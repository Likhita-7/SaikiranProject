package com.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dao.DoctorDAO;
import com.dao.UserDAO;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.modal.Doctor;
import com.modal.DoctorId;
import com.modal.Patients;
import com.modal.Slots;
import com.modal.User;
@Controller
public class MainControl {
	DoctorDAO da;
	UserDAO userObj;
	
	public MainControl(DoctorDAO da, UserDAO userObj) {
		this.da=da;
		this.userObj = userObj;
	}
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String Homepage(Model model) {
		return "login";
	}
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public String authentication(@Validated User c, Model model) {
		User c1 = userObj.getUser(c.getUserName());
		if(c1.getPassword().equals(c.getPassword())) {
			ArrayList<Doctor> aa= da.getAllDoctors();
			System.out.println(aa.size()+" size");
			model.addAttribute("doctors",aa);
			return "homepage";
		}
		else {
			return "login";
		}
	}
	
	@GetMapping(value = "/redirectToRegistration")
	public String RegistrationPage() {
		return "redirect:/registrationPage";
	}
	
	@RequestMapping(value = "/registrationPage", method = RequestMethod.GET)
	public String register() {
		return "registration";
	}
	
	@GetMapping(value="/redirectToLogin")
	public String LoginPage() {
		return "redirect:/";
	}
	
	@RequestMapping(value = "/createUser", method = RequestMethod.POST)
	public String createUser(@Validated User c) {
		int status = userObj.createUser(c);
		if(status > 0)
			return "registrationSuccess";
		else
			return "registrationFailed";
	}
	
	@RequestMapping(value="/slots" , method=RequestMethod.GET)
	@ResponseBody
	public String getSlots(DoctorId dd,Model modal) {
		String Doc_id=dd.getDoc_id();
		System.out.println(Doc_id);
		ArrayList<Slots> bb=da.getAvailableSlots(Integer.parseInt(Doc_id));
		Gson gson = new GsonBuilder()
                .setDateFormat("dd-MM-yyyy")
                .create();
		return gson.toJson(bb);	
	}
	@RequestMapping(value="/get_available_slots" , method=RequestMethod.GET)
	@ResponseBody
	public ArrayList<Slots> getSlotsById(Slots s,Model model) {
		System.out.println(s.toString());
		ArrayList<Slots> ss=da.getSlotsById(s);
		System.out.println(ss.toString());
		return ss;
		
	}
	@RequestMapping(value="/book",method=RequestMethod.GET)
	public String Booking(Patients p,Model model) {
		System.out.println(p.toString());
		da.updatePatients(p);
        da.updateDoctorSlots(p);
        da.updateAppointments(p);
        model.addAttribute("data", p);
		return "booked";
		
	}
}
