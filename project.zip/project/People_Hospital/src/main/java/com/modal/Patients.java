package com.modal;

public class Patients {
private String p_name,p_gender,p_bg,p_date,p_time;
private int p_age,s_id;
public int getS_id() {
	return s_id;
}
public void setS_id(int s_id) {
	this.s_id = s_id;
}
@Override
public String toString() {
	return "Patients [p_name=" + p_name + ", p_gender=" + p_gender + ", p_bg=" + p_bg + ", p_date=" + p_date
			+ ", p_time=" + p_time + ", p_age=" + p_age + ", s_id=" + s_id + ", p_phone=" + p_phone + "]";
}
public String getP_name() {
	return p_name;
}
public void setP_name(String p_name) {
	this.p_name = p_name;
}
public String getP_gender() {
	return p_gender;
}
public void setP_gender(String p_gender) {
	this.p_gender = p_gender;
}
public String getP_bg() {
	return p_bg;
}
public void setP_bg(String p_bg) {
	this.p_bg = p_bg;
}
public String getP_date() {
	return p_date;
}
public void setP_date(String p_date) {
	this.p_date = p_date;
}
public String getP_time() {
	return p_time;
}
public void setP_time(String p_time) {
	this.p_time = p_time;
}
public int getP_age() {
	return p_age;
}
public void setP_age(int p_age) {
	this.p_age = p_age;
}
public long getP_phone() {
	return p_phone;
}
public void setP_phone(long p_phone) {
	this.p_phone = p_phone;
}
private long p_phone;
}


