package com.modal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;
public class SlotMapper implements RowMapper<Slots> {
	public Slots  mapRow(ResultSet rs, int rowNum) throws SQLException {
		Slots s=new Slots();
		s.setS_id(rs.getInt(1));
		s.setS_did(rs.getInt(2));
		
			try {
				s.setS_date(rs.getDate(3));
			} catch (ParseException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		s.setS_ftime(rs.getString(4));
		s.setS_ttime(rs.getString(5));
		s.setS_status(rs.getString(6));
//		try {
////			System.out.println(s.getS_date());
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		return s;
	
	}
	 private Date parseDate(String dateString) {
	        try {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	            return dateFormat.parse(dateString);
	        } catch (ParseException e) {
	            throw new IllegalArgumentException("Invalid date format: " + dateString);
	        }
	    }
	
}
