package com.modal;

public class DoctorId {
	 private String doc_id;

	public String getDoc_id() {
		return doc_id;
	}

	public void setDoc_id(String doc_id) {
		this.doc_id = doc_id;
	}
	 

}
