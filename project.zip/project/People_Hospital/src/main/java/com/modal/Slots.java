package com.modal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Slots {
	private int S_id;
	private int s_did;
	private Date s_date;
	private String s_ftime,s_ttime,s_status;
	
	public String getS_status() {
		return s_status;
	}
	public void setS_status(String s_status) {
		this.s_status = s_status;
	}
	public Slots() {
		
	}
	public int getS_id() {
		return S_id;
	}
	public void setS_id(int s_id) {
		S_id = s_id;
	}
	public int getS_did() {
		return s_did;
	}
	public void setS_did(int s_did) {
		this.s_did = s_did;
	}
	public Date getS_date(){
	
		return s_date;
		
	}
	public void setS_date(Date s_date) throws ParseException {

	       this.s_date=s_date;
	}
	public String getS_ftime() {
		return s_ftime;
	}
	public void setS_ftime(String s_ftime) {
		this.s_ftime = s_ftime;
	}
	public String getS_ttime() {
		return s_ttime;
	}
	public void setS_ttime(String s_ttime) {
		this.s_ttime = s_ttime;
	}
	@Override
	public String toString() {
		return "Slots [S_id=" + S_id + ", s_did=" + s_did + ", s_date=" + s_date + ", s_ftime=" + s_ftime + ", s_ttime="
				+ s_ttime + ", s_status=" + s_status + "]";
	}
	
}
