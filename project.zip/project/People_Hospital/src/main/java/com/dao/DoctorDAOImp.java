package com.dao;

import java.util.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;


import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import com.modal.Doctor;
import com.modal.DoctorMapper;
import com.modal.Patients;
import com.modal.Slots;
import com.modal.SlotMapper;
public class DoctorDAOImp  implements DoctorDAO{

	JdbcTemplate jdbcTemplate;

	@Autowired
	public DoctorDAOImp(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private final String SQL_GET_DOCTORS = "select * from people_doctors";

	
	@Override
	public ArrayList<Doctor> getAllDoctors() {
		return (ArrayList<Doctor>) jdbcTemplate.query(SQL_GET_DOCTORS , new DoctorMapper());
	}

	@Override
	public ArrayList<Slots> getAvailableSlots(int id){
		ArrayList<Slots> a;
		a= (ArrayList<Slots>) jdbcTemplate.query("select * from people_Slots where slotdoctorid=? and slotstatus='available'",new Object[] {id}, new SlotMapper());
		System.out.println(a);
		return a;
	}

	@Override
	public ArrayList<Slots> getSlotsById(Slots s)  {
		ArrayList<Slots> a;
		a=  (ArrayList<Slots>) jdbcTemplate.query("select * from people_Slots where slotdoctorid=? and slotstatus='available' and slotdate=?",new Object[] {s.getS_did(),s.getS_date()}, new SlotMapper());
		return a;
	}

	@Override
	public void updatePatients(Patients p) {
	  jdbcTemplate.update("insert into people_patients values (?,?,?,?,?)" ,new Object[] {p.getP_name(),p.getP_age(),p.getP_gender(),p.getP_bg(),p.getP_phone()});
	  
		
	}

	@Override
	public void updateAppointments(Patients p) {

        
        // Define the input date format
        SimpleDateFormat inputDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        
        // Define the desired output date format
        SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            // Parse the input date string
            Date date = inputDateFormat.parse(p.getP_date());
            
            // Format the date in the desired output format
            String sqlDate = outputDateFormat.format(date);
            Date Dat=outputDateFormat.parse(sqlDate);
            

		System.out.println(Dat);
		
	
		  jdbcTemplate.update("insert into people_appointments values (?,?,?,?,?)" ,new Object[] {p.getS_id(),p.getP_name(),Dat,p.getP_time(),p.getP_phone()});

		
	}
        catch(Exception e)
        {
        	System.out.println(e);
        }
	}

	@Override
	public void updateDoctorSlots(Patients p) {
		// TODO Auto-generated method stub
		 jdbcTemplate.update("update people_slots set slotstatus=? where slotid=?" ,new Object[] {"booked",p.getS_id()});
		
	}

}
