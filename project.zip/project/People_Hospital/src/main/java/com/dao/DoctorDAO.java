package com.dao;

import java.util.ArrayList;

import com.modal.Doctor;
import com.modal.Patients;
import com.modal.Slots;

public interface DoctorDAO {
	ArrayList<Doctor> getAllDoctors();
	ArrayList<Slots> getAvailableSlots(int id);
	ArrayList<Slots> getSlotsById(Slots s);
	void updatePatients(Patients p);
	void updateDoctorSlots(Patients p);
	void updateAppointments(Patients p);

}
