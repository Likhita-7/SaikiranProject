package com.dao;

import com.modal.User;

public interface UserDAO {
	User getUser(String uname);
	int createUser(User c);
}